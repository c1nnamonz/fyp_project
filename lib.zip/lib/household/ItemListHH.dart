import 'package:flutter/material.dart';

class ItemListHousehold extends StatefulWidget {
  const ItemListHousehold({super.key});

  @override
  State<ItemListHousehold> createState() => _ItemListHouseholdState();
}

class _ItemListHouseholdState extends State<ItemListHousehold> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Item List'),
      ),
    );
  }
}
