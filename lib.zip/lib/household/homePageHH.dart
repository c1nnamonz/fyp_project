import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fyp_project/theme/theme.dart';
import 'package:intl/intl.dart';

class HomePageHousehold extends StatefulWidget {
  const HomePageHousehold({super.key});

  @override
  State<HomePageHousehold> createState() => _HomePageHouseholdState();
}

class _HomePageHouseholdState extends State<HomePageHousehold> {
  int selectedIndex = 0;
  String _userName = ''; // To store the user's name
  bool _isLoading = true; // To show loading state

  @override
  void initState() {
    super.initState();
    _fetchUserName();
  }

  Future<void> _fetchUserName() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (userDoc.exists) {
          setState(() {
            _userName = userDoc.data()?['fullName'] ?? 'User';
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      print('Error fetching user name: $e');
      setState(() {
        _userName = 'User';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    String currentDate = DateFormat('EEEE, MMMM d').format(DateTime.now());

    return Scaffold(
      body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(25.0, 25.0, 25.0, 15.0),
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : Row(
                children: [
                  Text(
                    'Hello, ',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey[600],
                    ),
                  ),
                  Text(
                    _userName,
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      color: lightColorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
          // Date Box - Now larger with top-aligned content
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Container(
              height: 210, // Increased height
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.3),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 0), // More padding at top
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Today',
                        style: TextStyle(
                          fontSize: 22, // Larger font size
                          fontWeight: FontWeight.bold,
                          color: lightColorScheme.primary,
                        ),
                      ),
                      Text(
                        currentDate,
                        style: TextStyle(
                          fontSize: 18, // Larger font size
                          color: Colors.grey[700],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Divider(
                          thickness: 0.7,
                          color: Colors.grey.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Groceries in-stock',
                        style: TextStyle(
                          fontSize: 25, // Larger font size
                          fontWeight: FontWeight.bold,
                          color: lightColorScheme.primary,

                        ),
                      ),

                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '15',
                        style: TextStyle(
                          fontSize: 34, // Larger font size
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,

                        ),
                      ),

                    ],
                  ),
                  // Space below the text
                  // You can add additional content here if needed
                ],
              ),
            ),
          ),
            Padding(
              padding: const EdgeInsets.fromLTRB(25.0, 5.0, 25.0, 5.0), // Reduced top & bottom
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'Expiring ',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: lightColorScheme.primary,
                        ),
                      ),

                      Text(
                        'Soon',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

// The box below (with minimal top padding)
            Padding(
              padding: const EdgeInsets.fromLTRB(12.0, 12, 12.0, 12.0), // Top padding = 0
              child: Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: lightColorScheme.primary,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.3),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
              ),
            ),

        ],
      ),
    );
  }
}