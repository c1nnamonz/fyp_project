import 'package:flutter/material.dart';

class NotificationHousehold extends StatefulWidget {
  const NotificationHousehold({super.key});

  @override
  State<NotificationHousehold> createState() => _notificationHouseholdState();
}

class _notificationHouseholdState extends State<NotificationHousehold> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Notification'),
      ),
    );
  }
}
