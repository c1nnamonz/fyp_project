import 'package:flutter/material.dart';
import 'package:fyp_project/theme/theme.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../widget/profile_widget.dart';

class ProfileHousehold extends StatefulWidget {
  const ProfileHousehold({super.key});

  @override
  State<ProfileHousehold> createState() => _ProfileHouseholdState();
}

class _ProfileHouseholdState extends State<ProfileHousehold> {
  String _userName = 'Loading...';
  String _userEmail = 'Loading...';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  Future<void> _fetchUserData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (userDoc.exists) {
          setState(() {
            _userName = userDoc.data()?['fullName'] ?? 'User';
            _userEmail = user.email ?? 'No email';
            _isLoading = false;
          });
        } else {
          // If user document doesn't exist, use auth email
          setState(() {
            _userName = 'User';
            _userEmail = user.email ?? 'No email';
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      print('Error fetching user data: $e');
      setState(() {
        _userName = 'Error loading name';
        _userEmail = 'Error loading email';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(16),
          height: size.height,
          width: size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 170,
                child: const CircleAvatar(
                  radius: 80,
                  backgroundColor: Colors.transparent,
                  backgroundImage: ExactAssetImage('images/profile.jpg'),
                ),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: lightColorScheme.primary.withOpacity(.5),
                    width: 5.0,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              _isLoading
                  ? const CircularProgressIndicator()
                  : SizedBox(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                  Padding(
                  padding: const EdgeInsets.only(right: 5.0),
                    child: Text(
                      _userName,
                      style: TextStyle(
                        color: Colors.black45,
                        fontSize: 18,
                      ),
                    ),
                  ),
                    SizedBox(
                        height: 24,
                        child: Image.asset("images/verified.png")),
                  ],
                ),
              ),
              _isLoading
                  ? const SizedBox()
                  : Text(
                _userEmail,
                style: TextStyle(
                  color: Colors.black45.withOpacity(.3),
                ),
              ),
              const SizedBox(height: 30),
              SizedBox(
                height: size.height * .7,
                width: size.width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    ProfileWidget(
                      icon: Icons.person,
                      title: 'My Profile',
                    ),
                    ProfileWidget(
                      icon: Icons.settings,
                      title: 'Settings',
                    ),
                    ProfileWidget(
                      icon: Icons.notifications,
                      title: 'Notifications',
                    ),
                    ProfileWidget(
                      icon: Icons.chat,
                      title: 'FAQs',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}